# Dark Mode Toggle Library

## Introduction

This library allows you to easily switch between light mode and dark mode on your website. It automatically changes the colors of page elements like background, text, and borders when switching to dark mode and back to light mode. By using this library, you can improve the user experience when they use your website in low-light conditions.

## Languages Used

- JavaScript (ES6+)

## Installation

To use this library, you can either copy the library code into your own JavaScript file or download it from the repository if available. Just make sure that the JavaScript file of the library is correctly linked in your website.

## How to Use

### Step 1: Download the file `dark-mode.min.js`

Download the code from `dist/dark-mode.min.js`

### Step 2:

Simply call the functions `revertToLightMode()` and `toggleDarkMode()` to turn on/off dark mode.