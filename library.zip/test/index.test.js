function toggleDarkMode() {
document.querySelectorAll('*').forEach(applyDarkModeStyles); 

observeChanges(); 

} 

function applyDarkModeStyles(element) {
if (!element.hasAttribute('data-original-bg')) {
element.setAttribute('data-original-bg', window.getComputedStyle(element).backgroundColor);
}
if (!element.hasAttribute('data-original-color')) {
element.setAttribute('data-original-color', window.getComputedStyle(element).color);
}
if (!element.hasAttribute('data-original-border')) {
element.setAttribute('data-original-border', window.getComputedStyle(element).borderColor);
} 

element.style.transition = 'background-color 0.3s, color 0.3s, border-color 0.3s';    

const originalBg = element.getAttribute('data-original-bg');    
const originalColor = element.getAttribute('data-original-color');    
const originalBorder = element.getAttribute('data-original-border');    

element.style.backgroundColor = getDarkModeBackgroundColor(originalBg);    
element.style.color = getDarkModeTextColor(originalColor);    
element.style.borderColor = getDarkModeBorderColor(originalBorder); 

} 

function getDarkModeBackgroundColor(originalBg) {
if (isLightColor(originalBg)) {
return '#000000'; 
} else if (isVeryLightColor(originalBg)) {
return '#2c2c2c';  
} else if (isMixedLightColor(originalBg)) {
return '#444444';  
}
return originalBg;
} 

function getDarkModeTextColor(originalColor) {
if (isDarkColor(originalColor)) {
return '#FFFFFF'; 
} else if (isMediumDarkColor(originalColor)) {
return '#CCCCCC'; 
} else if (isMixedDarkColor(originalColor)) {
return '#BBBBBB'; 
}
return originalColor;
}
function getDarkModeBorderColor(originalBorder) {
if (isLightColor(originalBorder)) {
return '#666666'; 
} else if (isVeryLightColor(originalBorder)) {
return '#444444'; 
}
return originalBorder;
}
function revertToLightMode() {
document.querySelectorAll('*').forEach(element => {
const originalBg = element.getAttribute('data-original-bg');
const originalColor = element.getAttribute('data-original-color');
const originalBorder = element.getAttribute('data-original-border'); 

if (originalBg) {    
        element.style.backgroundColor = originalBg;    
    }    
    if (originalColor) {    
        element.style.color = lightenColor(originalColor);    
    }    
    if (originalBorder) {    
        element.style.borderColor = originalBorder;    
    }    


    element.style.transition = 'background-color 0.3s, color 0.3s, border-color 0.3s';    
});    

disconnectObserver(); 

} 

function lightenColor(color) {
const rgb = colorToRgb(color);
return `rgb(${Math.min(rgb[0] + 40, 255)}, ${Math.min(rgb[1] + 40, 255)}, ${Math.min(rgb[2] + 40, 255)})`;
} 

function isLightColor(color) {
const rgb = colorToRgb(color);
return rgb[0] >= 240 && rgb[1] >= 240 && rgb[2] >= 240; // Light colors
} 

function isVeryLightColor(color) {
const rgb = colorToRgb(color);
return rgb[0] >= 230 && rgb[1] >= 230 && rgb[2] >= 230;
} 

function isDarkColor(color) {
const rgb = colorToRgb(color);
return rgb[0] <= 50 && rgb[1] <= 50 && rgb[2] <= 50; // Dark colors
} 

function isMediumDarkColor(color) {
const rgb = colorToRgb(color);
return rgb[0] <= 128 && rgb[1] <= 128 && rgb[2] <= 128;
} 

function isMixedLightColor(color) {
const rgb = colorToRgb(color);
return (rgb[0] > 200 && rgb[1] > 200 && rgb[2] > 200 && (rgb[0] < 240 || rgb[1] < 240 || rgb[2] < 240));
} 

function isMixedDarkColor(color) {
const rgb = colorToRgb(color);
return (rgb[0] < 100 && rgb[1] < 100 && rgb[2] < 100 && (rgb[0] > 50 || rgb[1] > 50 || rgb[2] > 50));
} 

function colorToRgb(color) {
let rgb = [];
if (color.startsWith('rgb')) {

rgb = color.match(/\d+/g).map(Number);
} else if (color.startsWith('#')) {
let hex = color.slice(1);
if (hex.length === 3) {
hex = hex.split('').map(h => h + h).join('');
}
rgb = [
parseInt(hex.slice(0, 2), 16),
parseInt(hex.slice(2, 4), 16),
parseInt(hex.slice(4, 6), 16)
];
}
return rgb;
} 

let observer; 

function observeChanges() {

if (observer) return; 

observer = new MutationObserver(mutations => {  
    mutations.forEach(() => {  
       
        document.querySelectorAll('*').forEach(applyDarkModeStyles);  
    });  
});  

observer.observe(document.body, {  
    childList: true,  
    subtree: true  
}); 

} 

function disconnectObserver() {
if (observer) {
observer.disconnect();
observer = null;
}
}